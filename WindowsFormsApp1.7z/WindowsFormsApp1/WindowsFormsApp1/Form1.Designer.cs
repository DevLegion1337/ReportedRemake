﻿namespace WindowsFormsApp1
{
    partial class spf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.login = new Guna.UI2.WinForms.Guna2Button();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Close = new Guna.UI2.WinForms.Guna2Button();
            this.minimize = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Discord = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Check = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.Label();
            this.SERIAL = new System.Windows.Forms.Label();
            this.UUID = new System.Windows.Forms.Label();
            this.DISK0 = new System.Windows.Forms.Label();
            this.MAC1 = new System.Windows.Forms.Label();
            this.MAC0 = new System.Windows.Forms.Label();
            this.TitleMac = new System.Windows.Forms.Label();
            this.TitleDisk = new System.Windows.Forms.Label();
            this.TitleSMBIOS = new System.Windows.Forms.Label();
            this.Expiry = new System.Windows.Forms.Label();
            this.NewClean = new System.Windows.Forms.CheckBox();
            this.Clean = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Spoof = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PanelError = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Watermark = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelError.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // login
            // 
            this.login.Animated = true;
            this.login.BorderRadius = 20;
            this.login.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.login.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.login.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.login.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.login.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.login.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login.ForeColor = System.Drawing.Color.White;
            this.login.Location = new System.Drawing.Point(0, 47);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(411, 44);
            this.login.TabIndex = 0;
            this.login.Text = "Authorize";
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.linkLabel1.Location = new System.Drawing.Point(386, 576);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(37, 15);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Help";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(227)))), ((int)(((byte)(227)))));
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.guna2TextBox1.BorderRadius = 17;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox1.ForeColor = System.Drawing.Color.White;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(3, 3);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '*';
            this.guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.White;
            this.guna2TextBox1.PlaceholderText = "";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(411, 38);
            this.guna2TextBox1.TabIndex = 4;
            this.guna2TextBox1.TextOffset = new System.Drawing.Point(75, 0);
            // 
            // Close
            // 
            this.Close.Animated = true;
            this.Close.BackColor = System.Drawing.Color.Transparent;
            this.Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Close.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.Close.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Close.ForeColor = System.Drawing.Color.White;
            this.Close.IndicateFocus = true;
            this.Close.Location = new System.Drawing.Point(389, 0);
            this.Close.Name = "Close";
            this.Close.PressedColor = System.Drawing.Color.Red;
            this.Close.PressedDepth = 70;
            this.Close.Size = new System.Drawing.Size(48, 35);
            this.Close.TabIndex = 6;
            this.Close.Text = "X";
            this.Close.UseTransparentBackground = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // minimize
            // 
            this.minimize.Animated = true;
            this.minimize.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.minimize.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.minimize.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.minimize.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.minimize.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.minimize.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.minimize.ForeColor = System.Drawing.Color.White;
            this.minimize.IndicateFocus = true;
            this.minimize.Location = new System.Drawing.Point(348, 0);
            this.minimize.Name = "minimize";
            this.minimize.PressedColor = System.Drawing.Color.Empty;
            this.minimize.PressedDepth = 70;
            this.minimize.Size = new System.Drawing.Size(48, 35);
            this.minimize.TabIndex = 7;
            this.minimize.Text = "-";
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.guna2TextBox1);
            this.panel1.Controls.Add(this.login);
            this.panel1.Controls.Add(this.Discord);
            this.panel1.Location = new System.Drawing.Point(12, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 305);
            this.panel1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(24, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 55136;
            this.label2.Text = "License";
            this.label2.UseWaitCursor = true;
            // 
            // Discord
            // 
            this.Discord.Animated = true;
            this.Discord.BorderRadius = 20;
            this.Discord.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Discord.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Discord.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Discord.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Discord.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.Discord.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.Discord.ForeColor = System.Drawing.Color.White;
            this.Discord.Image = global::WindowsFormsApp1.Properties.Resources.image_removebg_preview__9_;
            this.Discord.ImageOffset = new System.Drawing.Point(0, 2);
            this.Discord.ImageSize = new System.Drawing.Size(19, 15);
            this.Discord.IndicateFocus = true;
            this.Discord.Location = new System.Drawing.Point(0, 97);
            this.Discord.Name = "Discord";
            this.Discord.Size = new System.Drawing.Size(411, 44);
            this.Discord.TabIndex = 1;
            this.Discord.Text = "Discord";
            this.Discord.Click += new System.EventHandler(this.Discord_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.Check);
            this.panel2.Controls.Add(this.X);
            this.panel2.Controls.Add(this.SERIAL);
            this.panel2.Controls.Add(this.UUID);
            this.panel2.Controls.Add(this.DISK0);
            this.panel2.Controls.Add(this.MAC1);
            this.panel2.Controls.Add(this.MAC0);
            this.panel2.Controls.Add(this.TitleMac);
            this.panel2.Controls.Add(this.TitleDisk);
            this.panel2.Controls.Add(this.TitleSMBIOS);
            this.panel2.Controls.Add(this.Expiry);
            this.panel2.Controls.Add(this.NewClean);
            this.panel2.Controls.Add(this.Clean);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Spoof);
            this.panel2.Controls.Add(this.guna2TextBox2);
            this.panel2.Location = new System.Drawing.Point(9, 109);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(414, 464);
            this.panel2.TabIndex = 55137;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe MDL2 Assets", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Silver;
            this.label3.Location = new System.Drawing.Point(284, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 20);
            this.label3.TabIndex = 55155;
            this.label3.Text = "";
            this.label3.UseWaitCursor = true;
            // 
            // Check
            // 
            this.Check.AutoSize = true;
            this.Check.Font = new System.Drawing.Font("Segoe MDL2 Assets", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.ForeColor = System.Drawing.Color.Gray;
            this.Check.Location = new System.Drawing.Point(357, 20);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(32, 21);
            this.Check.TabIndex = 55154;
            this.Check.Text = "";
            this.Check.UseWaitCursor = true;
            // 
            // X
            // 
            this.X.AutoSize = true;
            this.X.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.X.ForeColor = System.Drawing.Color.Gray;
            this.X.Location = new System.Drawing.Point(320, 18);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(27, 25);
            this.X.TabIndex = 55153;
            this.X.Text = "X";
            this.X.UseWaitCursor = true;
            // 
            // SERIAL
            // 
            this.SERIAL.AutoSize = true;
            this.SERIAL.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SERIAL.ForeColor = System.Drawing.Color.White;
            this.SERIAL.Location = new System.Drawing.Point(13, 109);
            this.SERIAL.Name = "SERIAL";
            this.SERIAL.Size = new System.Drawing.Size(46, 14);
            this.SERIAL.TabIndex = 55150;
            this.SERIAL.Text = "SERIAL:";
            this.SERIAL.UseWaitCursor = true;
            // 
            // UUID
            // 
            this.UUID.AutoSize = true;
            this.UUID.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UUID.ForeColor = System.Drawing.Color.White;
            this.UUID.Location = new System.Drawing.Point(13, 92);
            this.UUID.Name = "UUID";
            this.UUID.Size = new System.Drawing.Size(33, 14);
            this.UUID.TabIndex = 55149;
            this.UUID.Text = "UUID:";
            this.UUID.UseWaitCursor = true;
            // 
            // DISK0
            // 
            this.DISK0.AutoSize = true;
            this.DISK0.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DISK0.ForeColor = System.Drawing.Color.White;
            this.DISK0.Location = new System.Drawing.Point(13, 176);
            this.DISK0.Name = "DISK0";
            this.DISK0.Size = new System.Drawing.Size(39, 14);
            this.DISK0.TabIndex = 55148;
            this.DISK0.Text = "DISK0:";
            this.DISK0.UseWaitCursor = true;
            // 
            // MAC1
            // 
            this.MAC1.AutoSize = true;
            this.MAC1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MAC1.ForeColor = System.Drawing.Color.White;
            this.MAC1.Location = new System.Drawing.Point(13, 271);
            this.MAC1.Name = "MAC1";
            this.MAC1.Size = new System.Drawing.Size(42, 14);
            this.MAC1.TabIndex = 55147;
            this.MAC1.Text = "MAC1: ";
            this.MAC1.UseWaitCursor = true;
            // 
            // MAC0
            // 
            this.MAC0.AutoSize = true;
            this.MAC0.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MAC0.ForeColor = System.Drawing.Color.White;
            this.MAC0.Location = new System.Drawing.Point(13, 248);
            this.MAC0.Name = "MAC0";
            this.MAC0.Size = new System.Drawing.Size(42, 14);
            this.MAC0.TabIndex = 55146;
            this.MAC0.Text = "MAC0: ";
            this.MAC0.UseWaitCursor = true;
            // 
            // TitleMac
            // 
            this.TitleMac.AutoSize = true;
            this.TitleMac.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.TitleMac.ForeColor = System.Drawing.Color.White;
            this.TitleMac.Location = new System.Drawing.Point(13, 230);
            this.TitleMac.Name = "TitleMac";
            this.TitleMac.Size = new System.Drawing.Size(51, 18);
            this.TitleMac.TabIndex = 55145;
            this.TitleMac.Text = "MACS";
            this.TitleMac.UseWaitCursor = true;
            // 
            // TitleDisk
            // 
            this.TitleDisk.AutoSize = true;
            this.TitleDisk.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.TitleDisk.ForeColor = System.Drawing.Color.White;
            this.TitleDisk.Location = new System.Drawing.Point(13, 156);
            this.TitleDisk.Name = "TitleDisk";
            this.TitleDisk.Size = new System.Drawing.Size(54, 18);
            this.TitleDisk.TabIndex = 55144;
            this.TitleDisk.Text = "DISKS";
            this.TitleDisk.UseWaitCursor = true;
            // 
            // TitleSMBIOS
            // 
            this.TitleSMBIOS.AutoSize = true;
            this.TitleSMBIOS.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.TitleSMBIOS.ForeColor = System.Drawing.Color.White;
            this.TitleSMBIOS.Location = new System.Drawing.Point(13, 74);
            this.TitleSMBIOS.Name = "TitleSMBIOS";
            this.TitleSMBIOS.Size = new System.Drawing.Size(68, 18);
            this.TitleSMBIOS.TabIndex = 55143;
            this.TitleSMBIOS.Text = "SMBIOS";
            this.TitleSMBIOS.UseWaitCursor = true;
            // 
            // Expiry
            // 
            this.Expiry.AutoSize = true;
            this.Expiry.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Expiry.ForeColor = System.Drawing.Color.White;
            this.Expiry.Location = new System.Drawing.Point(13, 441);
            this.Expiry.Name = "Expiry";
            this.Expiry.Size = new System.Drawing.Size(199, 14);
            this.Expiry.TabIndex = 55142;
            this.Expiry.Text = "License Expiry : ( 999 Days Remaining )";
            this.Expiry.UseWaitCursor = true;
            // 
            // NewClean
            // 
            this.NewClean.AutoSize = true;
            this.NewClean.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewClean.ForeColor = System.Drawing.Color.White;
            this.NewClean.Location = new System.Drawing.Point(16, 409);
            this.NewClean.Name = "NewClean";
            this.NewClean.Size = new System.Drawing.Size(194, 17);
            this.NewClean.TabIndex = 55140;
            this.NewClean.Text = "Generate New Seed on Clean";
            this.NewClean.UseVisualStyleBackColor = true;
            // 
            // Clean
            // 
            this.Clean.Animated = true;
            this.Clean.BackColor = System.Drawing.Color.Transparent;
            this.Clean.BorderRadius = 20;
            this.Clean.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Clean.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Clean.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Clean.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Clean.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.Clean.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.Clean.ForeColor = System.Drawing.Color.White;
            this.Clean.ImageOffset = new System.Drawing.Point(0, 2);
            this.Clean.ImageSize = new System.Drawing.Size(19, 15);
            this.Clean.IndicateFocus = true;
            this.Clean.Location = new System.Drawing.Point(3, 359);
            this.Clean.Name = "Clean";
            this.Clean.Size = new System.Drawing.Size(411, 44);
            this.Clean.TabIndex = 55139;
            this.Clean.Text = "Clean";
            this.Clean.UseTransparentBackground = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(27, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 55138;
            this.label1.Text = "Seed";
            this.label1.UseWaitCursor = true;
            // 
            // Spoof
            // 
            this.Spoof.Animated = true;
            this.Spoof.BackColor = System.Drawing.Color.Transparent;
            this.Spoof.BorderRadius = 20;
            this.Spoof.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Spoof.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Spoof.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Spoof.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Spoof.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.Spoof.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.Spoof.ForeColor = System.Drawing.Color.White;
            this.Spoof.ImageOffset = new System.Drawing.Point(0, 2);
            this.Spoof.ImageSize = new System.Drawing.Size(19, 15);
            this.Spoof.IndicateFocus = true;
            this.Spoof.Location = new System.Drawing.Point(0, 309);
            this.Spoof.Name = "Spoof";
            this.Spoof.Size = new System.Drawing.Size(411, 44);
            this.Spoof.TabIndex = 55137;
            this.Spoof.Text = "Spoof";
            this.Spoof.UseTransparentBackground = true;
            this.Spoof.Click += new System.EventHandler(this.Spoof_Click);
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.guna2TextBox2.BorderRadius = 17;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "123456789";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.guna2TextBox2.ForeColor = System.Drawing.Color.White;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.Location = new System.Drawing.Point(6, 12);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.White;
            this.guna2TextBox2.PlaceholderText = "";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.Size = new System.Drawing.Size(411, 41);
            this.guna2TextBox2.TabIndex = 55137;
            this.guna2TextBox2.TextOffset = new System.Drawing.Point(75, 0);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.image_removebg_preview__8_;
            this.pictureBox1.Location = new System.Drawing.Point(12, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(414, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // PanelError
            // 
            this.PanelError.Controls.Add(this.pictureBox2);
            this.PanelError.Controls.Add(this.label4);
            this.PanelError.Location = new System.Drawing.Point(12, 28);
            this.PanelError.Name = "PanelError";
            this.PanelError.Size = new System.Drawing.Size(414, 42);
            this.PanelError.TabIndex = 55138;
            this.PanelError.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelError_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.25F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(51, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 55156;
            this.label4.Text = "Spoof failure #2";
            this.label4.UseWaitCursor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources.image_removebg_preview__13_1;
            this.pictureBox2.Location = new System.Drawing.Point(21, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 55157;
            this.pictureBox2.TabStop = false;
            // 
            // Watermark
            // 
            this.Watermark.AutoSize = true;
            this.Watermark.Font = new System.Drawing.Font("Arial", 9.25F);
            this.Watermark.ForeColor = System.Drawing.Color.White;
            this.Watermark.Location = new System.Drawing.Point(6, 9);
            this.Watermark.Name = "Watermark";
            this.Watermark.Size = new System.Drawing.Size(126, 16);
            this.Watermark.TabIndex = 55158;
            this.Watermark.Text = "Made by 2fine/legion";
            this.Watermark.UseWaitCursor = true;
            // 
            // spf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ClientSize = new System.Drawing.Size(435, 600);
            this.Controls.Add(this.Watermark);
            this.Controls.Add(this.PanelError);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.minimize);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.linkLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "spf";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.spf_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelError.ResumeLayout(false);
            this.PanelError.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button login;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2Button Discord;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2Button Close;
        private Guna.UI2.WinForms.Guna2Button minimize;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button Spoof;
        private System.Windows.Forms.CheckBox NewClean;
        private Guna.UI2.WinForms.Guna2Button Clean;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private System.Windows.Forms.Label TitleSMBIOS;
        private System.Windows.Forms.Label Expiry;
        private System.Windows.Forms.Label MAC0;
        private System.Windows.Forms.Label TitleMac;
        private System.Windows.Forms.Label TitleDisk;
        private System.Windows.Forms.Label SERIAL;
        private System.Windows.Forms.Label UUID;
        private System.Windows.Forms.Label DISK0;
        private System.Windows.Forms.Label MAC1;
        private System.Windows.Forms.Label Check;
        private System.Windows.Forms.Label X;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel PanelError;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Watermark;
    }
}

