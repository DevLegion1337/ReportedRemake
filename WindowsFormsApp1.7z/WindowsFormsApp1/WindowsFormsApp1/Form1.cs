﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class spf : Form
    {
        public spf()
        {
            InitializeComponent();
        }

        private void spf_Load(object sender, EventArgs e)
        {
            panel2.Hide();
            PanelError.Hide();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
           this.WindowState = FormWindowState.Minimized;
        }

        private void login_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Show();

        }

        private async void Discord_Click(object sender, EventArgs e)
        {
            Process.Start("https://discord.gg/legionexe");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://discord.gg/legionexe");
        }

        private async void Spoof_Click(object sender, EventArgs e)
        {
            PanelError.Show();
            PanelError.BackColor = Color.FromArgb(182, 35, 35, 35);
            MessageBox.Show("No Drivers Has Been Implemented", "Reported.lol [made by ur boy legion]");
            Task.Delay(1000);
            PanelError.Hide();
        }

        private void PanelError_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
